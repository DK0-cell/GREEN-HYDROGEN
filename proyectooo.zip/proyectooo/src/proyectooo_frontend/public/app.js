import { Actor, HttpAgent } from '@dfinity/agent';
import { idlFactory as TokenIdlFactory, canisterId as tokenId } from '../.dfx/local/token';

const agent = new HttpAgent();
const token = Actor.createActor(TokenIdlFactory, { agent, canisterId: tokenId });

async function updateBalance() {
    const principal = await token.whoami();
    const balance = await token.balanceOf(principal);
    document.getElementById('balance').textContent = balance.toString();
}

document.getElementById('transferForm').addEventListener('submit', async (event) => {
    event.preventDefault();
    const formData = new FormData(event.target);
    const to = formData.get('to');
    const amount = Number(formData.get('amount'));

    try {
        await token.transfer(to, amount);
        document.getElementById('status').textContent = 'Transfer successful!';
        updateBalance();
    } catch (error) {
        document.getElementById('status').textContent = 'Transfer failed!';
        console.error('Error transferring tokens:', error);
    }
});

updateBalance();
